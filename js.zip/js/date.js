var now = new Date();
var datetime = now.toDateString();

// Insert date and time into HTML
document.getElementById("demo").innerHTML = datetime;

var today = new Date()
var year = today.getFullYear()
document.getElementById("years").innerHTML = year;